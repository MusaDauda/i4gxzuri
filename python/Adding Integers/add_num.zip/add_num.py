#Ask Users For Inputs
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))
#Add the input
sum = num1 + num2
# Round the result to 2 Decimal places
sum_r = round(sum,2)
# print output
print(f"The addition of {num1} and {num2} equals {sum_r}")